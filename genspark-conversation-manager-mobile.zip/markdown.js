/* Shared Markdown export for the content script and popup. No remote dependencies. */
(function (root) {
    'use strict';
    const skipTags = new Set(['SCRIPT', 'STYLE', 'NOSCRIPT', 'BUTTON', 'SVG', 'INPUT', 'TEXTAREA', 'SELECT']);
    const escapeText = text => String(text).replace(/\s+/g, ' ').replace(/([\\`*_[\]<>])/g, '\\$1');
    const children = node => Array.from(node.childNodes || []);
    const tag = node => (node.tagName || '').toUpperCase();
    const attr = (node, name) => node.getAttribute?.(name) || '';
    const clean = text => text.trim();
    function safeUrl(value, base) {
        if (!value) return '';
        try {
            const url = new URL(value, base);
            if (!['https:', 'http:', 'mailto:'].includes(url.protocol)) return '';
            return url.href.replace(/[<>\s()]/g, character => encodeURIComponent(character));
        } catch { return ''; }
    }
    function fromElement(element, base = root.location?.href || 'https://www.genspark.ai/') {
        function render(node) {
            if (node.nodeType === 3) return escapeText(node.textContent || '');
            const name = tag(node);
            if (skipTags.has(name) || attr(node, 'aria-hidden') === 'true') return '';
            const inside = () => children(node).map(render).join('');
            if (name === 'BR') return '\n';
            if (name === 'HR') return '\n\n---\n\n';
            if (name === 'PRE') {
                const code = node.querySelector('code') || node;
                const value = (code.textContent || '').replace(/\n$/, '');
                const runs = value.match(/`+/g) || [];
                const fence = '`'.repeat(Math.max(3, ...runs.map(run => run.length + 1)));
                const language = (attr(code, 'class').match(/(?:^|\s)language-([\w+-]+)/) || [])[1] || '';
                return `\n\n${fence}${language}\n${value}\n${fence}\n\n`;
            }
            if (name === 'CODE') {
                const value = (node.textContent || '').replace(/\n/g, ' ');
                const fence = '`'.repeat(Math.max(1, ...(value.match(/`+/g) || []).map(run => run.length + 1)));
                const pad = /^`|`$|^ .* $/.test(value) ? ' ' : '';
                return `${fence}${pad}${value}${pad}${fence}`;
            }
            if (name === 'STRONG' || name === 'B') return `**${inside().trim()}**`;
            if (name === 'EM' || name === 'I') return `*${inside().trim()}*`;
            if (name === 'DEL' || name === 'S') return `~~${inside().trim()}~~`;
            if (name === 'A') {
                const label = inside().trim();
                const href = safeUrl(attr(node, 'href'), base);
                return href ? `[${label || href}](<${href}>)` : label;
            }
            if (name === 'IMG') {
                // Prefer the full-resolution source when Genspark serves a thumbnail.
                const src = safeUrl(attr(node, 'data-src') || attr(node, 'data-original') || attr(node, 'src'), base);
                return src ? `![${escapeText(attr(node, 'alt'))}](<${src}>)` : escapeText(attr(node, 'alt'));
            }
            if (/^H[1-6]$/.test(name)) return `\n\n${'#'.repeat(Number(name[1]))} ${inside().trim()}\n\n`;
            if (name === 'BLOCKQUOTE') return `\n\n${clean(inside()).split('\n').map(line => `> ${line}`).join('\n')}\n\n`;
            if (name === 'UL' || name === 'OL') {
                const start = Number.parseInt(attr(node, 'start'), 10) || 1;
                const items = children(node).filter(child => tag(child) === 'LI');
                return '\n\n' + items.map((item, index) => {
                    const marker = name === 'OL' ? `${start + index}. ` : '- ';
                    const value = clean(children(item).map(render).join(''));
                    return marker + value.replace(/\n/g, '\n' + ' '.repeat(marker.length));
                }).join('\n') + '\n\n';
            }
            if (name === 'TABLE') {
                const rows = [];
                const collect = current => {
                    for (const child of children(current)) {
                        if (tag(child) === 'TR') rows.push(child);
                        else if (['THEAD', 'TBODY', 'TFOOT'].includes(tag(child))) collect(child);
                    }
                };
                collect(node);
                const cells = rows.map(row => children(row).filter(cell => ['TH', 'TD'].includes(tag(cell)))
                    .map(cell => clean(children(cell).map(render).join('')).replace(/\|/g, '\\|').replace(/\n+/g, '<br>')));
                if (!cells.length) return '';
                const width = Math.max(...cells.map(row => row.length));
                const line = row => '| ' + Array.from({ length: width }, (_, index) => row[index] || '').join(' | ') + ' |';
                return '\n\n' + [line(cells[0]), line(Array(width).fill('---')), ...cells.slice(1).map(line)].join('\n') + '\n\n';
            }
            if (['P', 'DIV', 'SECTION', 'ARTICLE', 'FIGURE', 'FIGCAPTION', 'DL', 'DT', 'DD'].includes(name)) {
                return '\n\n' + inside() + '\n\n';
            }
            return inside();
        }
        // Collapse wrapper spacing without changing blank lines inside fenced code.
        const output = render(element).trim();
        const fenced = /(^|\n)(`{3,})[^\n]*\n[\s\S]*?\n\2(?=\n|$)/g;
        let result = '', cursor = 0;
        for (const match of output.matchAll(fenced)) {
            result += output.slice(cursor, match.index).replace(/\n{3,}/g, '\n\n') + match[0];
            cursor = match.index + match[0].length;
        }
        return (result + output.slice(cursor).replace(/\n{3,}/g, '\n\n')).trim();
    }
    function renderConversation({ title = 'Genspark conversation', url = '', messages = [], exportedAt = new Date().toISOString(), created = '' }) {
        let parsed;
        try { parsed = new URL(url); } catch { /* Old saved conversations may lack a URL. */ }
        const fields = { title, url, conversation_id: parsed?.searchParams.get('id') || '',
            source: parsed?.hostname || 'genspark.ai' };
        if (created) fields.created = created;
        fields.exported_at = exportedAt;
        const metadata = Object.entries(fields).map(([key, value]) => `${key}: ${JSON.stringify(String(value))}`).join('\n');
        const heading = String(title).replace(/[\r\n]+/g, ' ');
        const turns = messages.map(message => `## ${message.type === 'user' ? 'You' : 'Genspark'}\n\n${message.markdown || message.content || ''}`);
        return `---\n${metadata}\n---\n\n# ${heading}\n\n${turns.join('\n\n')}\n`;
    }

    const localDate = (date = new Date()) => `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
    // Windows- and Obsidian-safe name segment: no path separators, wildcards,
    // control characters, wiki-link brackets or leading/trailing dots and spaces.
    function safeName(value, fallback = 'Genspark conversation', limit = 100) {
        const normalized = String(value || '').normalize('NFC')
            .replace(/[<>:"/\\|?*\x00-\x1f[\]#^]/g, '_').replace(/\s+/g, ' ').trim()
            .replace(/^[. ]+|[. ]+$/g, '');
        return Array.from(normalized).slice(0, limit).join('') || fallback;
    }
    function filename(title, date = new Date(), extension = 'md') {
        return `${localDate(date)}-${safeName(title, 'Genspark conversation', 160)}.${extension}`;
    }
    // "<title>.md" travels together with its "<title>_assets/images/" folder.
    function exportNames(title, date = new Date()) {
        const base = `${localDate(date)}-${safeName(title, 'Genspark conversation', 120)}`;
        return { base, markdown: `${base}.md`, assets: `${base}_assets`, zip: `${base}.zip` };
    }

    const KIND_LABELS = { generated: 'generated-image', uploaded: 'uploaded-image', snapshot: 'page-image', external: 'external-image' };
    const GENERATED_URL = /\/api\/files\//i;
    const UPLOADED_URL = /(?:^|[-_/])(?:user[-_]?)?(?:upload|attachment|temp|private)(?:s|ed)?(?:[-_/]|$)/i;
    const IMAGE_ATTRIBUTES = /\s(?:src|data-src|data-original|data-image|href|poster)="([^"]+)"/g;

    const decodeAttribute = value => String(value || '').replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>');
    const escapeAttribute = value => String(value || '').replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;');
    const escapePattern = value => value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const imageExtension = pathname => (pathname.match(/\.(png|jpe?g|webp|gif|avif)$/i) || [, 'png'])[1].toLowerCase().replace('jpeg', 'jpg');
    const usableImage = url => !/^data:image\/(?:[\w.+-]+;)?base64,/i.test(url) && !/^https?:\/\/[^?]*\.(?:svg|ico)$/i.test(url);

    function urlKind(parsed, base) {
        if (GENERATED_URL.test(parsed.pathname)) return 'generated';
        if (UPLOADED_URL.test(parsed.pathname)) return 'uploaded';
        try { if (parsed.hostname === new URL(base).hostname) return 'snapshot'; } catch { /* Keep the static base. */ }
        return 'external';
    }
    // Which images do the given Markdown URLs, HTML attributes or DOM
    // observations ({ url, alt, width }) refer to? Produces stable local names
    // (img-01-generated-image.png, external-<stem>.png, ...) with generated
    // illustrations numbered in conversation order. Keeping this free of browser
    // APIs makes download ordering testable in Node.
    function planImages({ html = '', urls = [], images = [], base = 'https://www.genspark.ai/' } = {}) {
        const observations = new Map();
        for (const image of images) {
            if (!image?.url) continue;
            try {
                const absolute = new URL(decodeAttribute(image.url), base);
                absolute.hash = '';
                if (!observations.has(absolute.href)) observations.set(absolute.href, image);
            } catch { /* Ignore pseudo-URLs; they are rejected below as well. */ }
        }
        const markupSources = [
            ...Array.from(html.matchAll(IMAGE_ATTRIBUTES), match => match[1]),
            ...Array.from(html.matchAll(/!\[\[([^\]|]+)(?:\|[^\]]*)?\]\]/g), match => match[1]),
            ...Array.from(html.matchAll(/!?\[[^\]]*\]\((<[^>]+>|[^)\s]+)\)/g), match => match[1])
        ].map(decodeAttribute);
        const candidates = [...urls, ...urls.filter(Boolean).map(source => String(source).replace(/^<|>$/g, '')), ...markupSources,
            ...images.map(image => image?.url)].filter(Boolean).map(source => decodeAttribute(String(source).replace(/^<|>$/g, '')));
        const entries = [], byUrl = new Map(), skipped = [];
        let generatedCount = 0, pageCount = 0;
        for (const candidate of candidates) {
            if (/^data:image\//i.test(candidate)) {
                if (!skipped.some(item => item.reason === 'inline')) skipped.push({ url: 'data:image/…', reason: 'inline' });
                continue;
            }
            let parsed;
            try { parsed = new URL(candidate, base); } catch { if (!skipped.some(item => item.url === candidate)) skipped.push({ url: candidate.slice(0, 120), reason: 'invalid' }); continue; }
            if (!['https:', 'http:'].includes(parsed.protocol) || !usableImage(parsed.href)) continue;
            parsed.hash = '';
            if (byUrl.has(parsed.href)) continue;
            const url = parsed.href;
            const kind = urlKind(parsed, base);
            const extension = imageExtension(parsed.pathname);
            const stem = (parsed.pathname.split('/').filter(Boolean).pop() || '').replace(/\.[a-z0-9]{2,5}$/i, '')
                .replace(/[^A-Za-z0-9_-]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 40);
            let name;
            if (kind === 'generated') name = `img-${String(++generatedCount).padStart(2, '0')}-${KIND_LABELS.generated}.${extension}`;
            else if (kind === 'snapshot') name = `img-${String(++pageCount).padStart(2, '0')}-${KIND_LABELS.snapshot}.${extension}`;
            else name = `${KIND_LABELS[kind]}-${stem || `image-${entries.length + 1}`}.${extension}`;
            while (entries.some(entry => entry.name === name)) name = name.replace(/(\.[a-z]+)$/, '-x$1');
            const observed = observations.get(url);
            const entry = { url, name, kind, path: `images/${name}` };
            if (observed?.alt) entry.alt = String(observed.alt);
            if (Number(observed?.width) >= 80) entry.width = Math.min(Math.round(Number(observed.width)), 2000);
            byUrl.set(url, entry);
            entries.push(entry);
        }
        return { base, entries, skipped, matches: url => byUrl.get(String(url)) || null };
    }

    const OBSIDIAN_LINK = /!\[\[([^\]|#\n]+?)(?:\|([^\]\n]*))?\]\]/g;

    // Point image links at the bundled copies. Markdown links with spaces or
    // non-ASCII paths use the angle form "![](<images/a b.png>)".
    function rewriteImageLinks(text, plan) {
        if (!plan?.entries?.length) return text;
        const mark = path => (/[\s()<>]/.test(path) ? `<${path}>` : path);
        const lookup = source => {
            if (!source) return null;
            let decoded = source;
            try { decoded = decodeURI(source); } catch { /* Keep the raw source. */ }
            // Fetched bytes may come from the signed variant (?cache_control=...)
            // while the plan holds the plain URL, or the other way round.
            let unsigned = source;
            try { const parsed = new URL(source, plan.base); parsed.search = ''; unsigned = parsed.href; } catch { /* keep source */ }
            for (const candidate of [source, decoded, unsigned]) {
                try {
                    const parsed = new URL(candidate, plan.base);
                    parsed.hash = '';
                    parsed.search = '';
                    const entry = plan.matches(parsed.href);
                    if (entry) return entry;
                } catch { /* Try the next form. */ }
                const direct = plan.matches(candidate);
                if (direct) return direct;
            }
            return null;
        };
        const withWikiLinks = String(text || '').replace(OBSIDIAN_LINK, (whole, source, size) => {
            const entry = /^https?:/i.test(source) ? lookup(source) : null;
            return entry ? `![[${entry.path}${size ? `|${size}` : ''}]]` : whole;
        });
        return withWikiLinks.replace(/(!?\[[^[\]]*\]\()(<[^>]+>|[^)\s]+)(\s+"[^"]*")?\)|<img\b[^>]*>/g,
            (whole, prefix, rawSource, title) => {
                if (!prefix) {
                    const entry = lookup(decodeAttribute((whole.match(/\ssrc="([^"]*)"/) || [])[1] || ''));
                    return !entry ? whole : whole.replace(/\ssrc="[^"]*"/, () => ` src="${entry.path}"`);
                }
                // Links that are not part of the plan (already-local files included) stay as they are.
                const entry = lookup(rawSource.startsWith('<') ? rawSource.slice(1, -1) : rawSource);
                return !entry ? whole : `${prefix}${mark(entry.path)}${title || ''})`;
            });
    }

    const BLOCK_TAGS = new Set(['p', 'div', 'section', 'article', 'main', 'header', 'footer', 'body', 'ul', 'ol', 'table', 'tr', 'figure', 'details', 'summary']);
    const VOID_TAGS = new Set(['img', 'br', 'hr', 'input', 'meta', 'link', 'source']);
    const attributes = raw => {
        const result = {};
        for (const match of String(raw || '').matchAll(/([\w:-]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'>]+)))?/g)) {
            result[match[1].toLowerCase()] = match[2] ?? match[3] ?? match[4] ?? '';
        }
        return result;
    };
    /**
     * Tokenizing HTML → Markdown for the archive reader (archive.js). The same
     * dialect as fromElement, so page and archive exports stay comparable.
     */
    function htmlToMarkdown(html, base = 'https://www.genspark.ai/') {
        const source = String(html || '').replace(/<(script|style|noscript|template)[\s\S]*?<\/\1\s*>/gi, '');
        const stack = [{ tag: '#root', attrs: {}, inner: '' }];
        const wrap = (tag, inner, attrs) => {
            const text = inner.trim();
            switch (tag) {
                case '#root': return inner;
                case 'img': {
                    const src = attrs['data-src'] || attrs.src || '';
                    return src ? `![${attrs.alt || ''}](<${safeUrl(src, base) || src}>)` : '';
                }
                case 'br': return '\n';
                case 'hr': return '\n\n---\n\n';
                case 'strong': case 'b': return text ? `**${text}**` : inner;
                case 'em': case 'i': return text ? `*${text}*` : inner;
                case 'del': case 's': return text ? `~~${text}~~` : inner;
                case 'code': return `\`${inner.replace(/\n/g, ' ')}\``;
                case 'pre': return `\n\n\`\`\`\n${inner.replace(/\n$/, '')}\n\`\`\`\n\n`;
                case 'a': {
                    const href = safeUrl(attrs.href, base);
                    return href ? `[${text || href}](<${href}>)` : inner;
                }
                case 'li': return `\n- ${text}`;
                case 'h1': case 'h2': case 'h3': case 'h4': case 'h5': case 'h6':
                    return `\n\n${'#'.repeat(Number(tag[1]))} ${text}\n\n`;
                case 'blockquote': return `\n\n${text.split('\n').map(line => `> ${line}`).join('\n')}\n\n`;
                case 'td': case 'th': return ` ${text} |`;
                case 'tr': return `\n| ${text}`;
                default: return BLOCK_TAGS.has(tag) ? `\n\n${text}\n\n` : inner;
            }
        };
        const close = tag => {
            for (let index = stack.length - 1; index > 0; index--) {
                if (stack[index].tag !== tag) continue;
                const open = stack[index];
                stack.length = index;
                return open;
            }
            return null;
        };
        for (const token of source.match(/<[^>]*>|[^<]+/g) || []) {
            if (!token.startsWith('<')) {
                stack[stack.length - 1].inner += decodeEntities(token).replace(/\s+/g, ' ');
                continue;
            }
            const match = /^<\s*(\/?)\s*([a-z][\w-]*)((?:[^>"']|"[^"]*"|'[^']*')*?)\s*(\/?)>$/i.exec(token);
            if (!match) continue;
            const tag = match[2].toLowerCase();
            const attrs = attributes(match[3]);
            if (match[1]) {
                const open = close(tag);
                if (open) stack[stack.length - 1].inner += wrap(tag, open.inner, open.attrs);
            } else if (VOID_TAGS.has(tag) || match[4] === '/') {
                stack[stack.length - 1].inner += wrap(tag, '', attrs);
            } else {
                stack.push({ tag, attrs, inner: '' });
            }
        }
        // Unclosed elements are closed innermost-first, as a browser would.
        while (stack.length > 1) {
            const open = stack.pop();
            stack[stack.length - 1].inner += wrap(open.tag, open.inner, open.attrs);
        }
        return wrap('#root', stack[0].inner, {})
            .replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim();
    }
    const decodeEntities = value => String(value).replace(/&(#x?[0-9a-f]+|[a-z]+);/gi, (whole, name) => {
        if (/^#x/i.test(name)) return String.fromCodePoint(Number.parseInt(name.slice(2), 16) || 0);
        if (name[0] === '#') return String.fromCodePoint(Number.parseInt(name.slice(1), 10) || 0);
        return ({ amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ' })[name.toLowerCase()] ?? whole;
    });
    root.GensparkMarkdown = { fromElement, renderConversation, filename, exportNames, safeName, planImages, rewriteImageLinks, htmlToMarkdown };
})(globalThis);