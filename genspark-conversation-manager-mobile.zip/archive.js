/* Session-archive fallback for the background worker. No DOM, no remote code.
 *
 * Not every conversation is open in a tab. The archive reads a conversation
 * without the extension's DOM extraction:
 *   1. render it in a hidden tab and read the packaged HTML reader's output;
 *   2. use JSON embedded in the page, else ask known conversation endpoints
 *      (private and undocumented, so a miss simply falls through);
 *   3. keep the /api/files/s/<id> image URLs found in the markup, which need
 *      no login and can become images/ files like the page export does.
 * Every step is best effort; the attempts list records what happened.
 */
(function (root) {
    'use strict';
    const LIMIT = { html: 12 * 1024 * 1024, body: 24 * 1024 * 1024, timeout: 30000 };
    const IMAGE_LINK = /!\[[^\]]*\]\((?:<([^>]+)>|([^)\s]+))\)|<img\b[^>]*?\s(?:src|data-src)="([^"]+)"/gi;

    function conversationId(url) {
        try {
            const parsed = new URL(url);
            return parsed.searchParams.get('id') || parsed.searchParams.get('conversation_id') ||
                (parsed.pathname.match(/\/agents?\/([\w-]{8,})/) || [])[1] || '';
        } catch { return ''; }
    }

    /** Candidate JSON endpoints, most likely first. Unknown ones are skipped. */
    function jsonEndpoints(url, id) {
        let origin = 'https://www.genspark.ai';
        try { origin = new URL(url).origin; } catch { /* keep default */ }
        if (!id) return [];
        const encoded = encodeURIComponent(id);
        return [
            `${origin}/api/agent/conversation_detail?conversation_id=${encoded}`,
            `${origin}/api/copilot/conversation?conversation_id=${encoded}`,
            `${origin}/api/project/detail?project_id=${encoded}`,
            `${origin}/api/agent/message/list?conversation_id=${encoded}`
        ];
    }

    /** Deep search for a message list; tolerant of wrapper key names. */
    function findMessages(value, depth = 0) {
        if (!value || depth > 8) return [];
        if (Array.isArray(value)) {
            if (value.length > 1 && value.every(item => item && typeof item === 'object' && ('content' in item || 'text' in item || 'message' in item))) return value;
            for (const item of value) {
                const found = findMessages(item, depth + 1);
                if (found.length) return found;
            }
            return [];
        }
        if (typeof value !== 'object') return [];
        for (const key of ['messages', 'conversation', 'history', 'chats', 'items', 'data', 'activity_data']) {
            if (key in value) {
                const found = findMessages(value[key], depth + 1);
                if (found.length) return found;
            }
        }
        return [];
    }

    const textValue = content => {
        if (typeof content === 'string') return content;
        if (Array.isArray(content)) return content.map(part => (typeof part === 'string' ? part : part?.text || part?.content || '')).join('\n');
        if (content && typeof content === 'object') return content.text || content.markdown || content.content || '';
        return '';
    };

    /** Normalize message objects to the { type, content, markdown } shape the exporter uses. */
    function normalizeMessages(raw) {
        return (Array.isArray(raw) ? raw : []).map(item => {
            const role = String(item.role || item.type || item.author?.role || item.sender || '').toLowerCase();
            const type = /user|human|me$/.test(role) ? 'user' : /system/.test(role) ? '' : 'assistant';
            const content = textValue(item.content ?? item.message ?? item.text);
            const markdown = typeof content === 'string' ? content.trim() : '';
            return { type, content: markdown, markdown };
        }).filter(message => message.type && message.content);
    }

    function imageLinks(markdown) {
        return Array.from(String(markdown || '').matchAll(IMAGE_LINK), match => (match[1] || match[2] || match[3] || '').trim())
            .filter(source => source && !/^data:/i.test(source)).map(source => source.replace(/&amp;/g, '&'));
    }

    /** Convert a JSON payload to messages, or null when it has no conversation text. */
    function fromJson(payload, { title = '', url = '', extraUrls = [] } = {}) {
        const messages = normalizeMessages(findMessages(payload));
        if (!messages.length) return null;
        const imageUrls = [...new Set([...messages.flatMap(message => imageLinks(message.markdown)), ...extraUrls])];
        return {
            title: title || payload?.title || payload?.conversation?.title || payload?.data?.title || '',
            created: payload?.created_at || payload?.createdAt || payload?.conversation?.created_at || payload?.data?.created_at || '',
            messages, imageUrls
        };
    }

    /** Extract a JSON state object assigned in an inline script without running it. */
    function inlineState(html) {
        const next = /<script id="__NEXT_DATA__"[^>]*>([\s\S]*?)<\/script>/.exec(html);
        const assigned = /window\.__(?:GSX_STATE|NUXT__|INITIAL_STATE|GS_STATE|APOLLO_STATE)__\s*=\s*(\{[\s\S]*?\})\s*;?\s*<\/script>/.exec(html);
        const found = next?.[1] || assigned?.[1];
        if (!found) return null;
        try { return JSON.parse(found); } catch { return null; }
    }

    /** A JSON body is never a document, even when the server labels it text/html. */
    const looksLikeJson = body => /^\s*[[{]/.test(body) && (() => { try { JSON.parse(body); return true; } catch { return false; } })();

    async function fetchText(fetchImpl, url, expectJson) {
        if (typeof fetchImpl !== 'function') return { ok: false, status: 0, error: 'noFetch' };
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), LIMIT.timeout);
        try {
            const response = await fetchImpl(url, {
                credentials: 'include', signal: controller.signal, redirect: 'follow',
                // Lets the caller skip the plain fetch for endpoints where a
                // reader-page request is known to be needed.
                method: expectJson ? 'endpoint' : 'get',
                headers: { Accept: expectJson ? 'application/json, text/plain, */*' : 'text/html,application/xhtml+xml' }
            });
            const body = await response.text();
            if (body.length > LIMIT[expectJson ? 'body' : 'html']) return { ok: false, status: response.status, error: 'tooLarge' };
            return { ok: (response.ok || response.status === 0) && body.length > 0, status: response.status, body,
                contentType: response.headers.get('content-type') || '' };
        } catch (error) {
            return { ok: false, status: 0, error: error?.name === 'AbortError' ? 'timeout' : String(error?.message || error) };
        } finally {
            clearTimeout(timer);
        }
    }

    /** Image URLs in a markup string that look like the page export's generated files. */
    const filesInMarkup = html => [...new Set(imageLinks(html))].filter(url => /\/api\/files\/[sdp]\//.test(url));

    /**
     * @param {object} options
     * @param {string} options.url
     * @param {string} [options.title]
     * @param {(url: string) => Promise<{ html: string, title?: string, created?: string }|null>} [options.renderPage]
     *        Renders the conversation in a hidden tab; parsing happens with GensparkArchiveHtml.read.
     * @param {Function} [options.fetch]
     */
    async function archiveConversation({ url, title = '', renderPage, fetch: fetchImpl = root.fetch?.bind(root) }) {
        const attempts = [];
        const id = conversationId(url);
        const result = { ok: false, source: '', markdown: '', imageUrls: [], created: '',
            title: title || id || 'Genspark conversation', attempts };
        if (!url) return { ...result, error: 'noUrl' };

        let html = '';
        // 1. Rendered page (DOM extraction happens in the tab's content script).
        try {
            const rendered = await renderPage?.(url);
            if (rendered?.html) {
                html = rendered.html;
                result.title = rendered.title || result.title;
                result.created = rendered.created || '';
                attempts.push({ step: 'render', ok: true, characters: html.length });
            } else {
                attempts.push({ step: 'render', ok: false, status: rendered?.status, error: rendered?.error || 'empty' });
            }
        } catch (error) {
            attempts.push({ step: 'render', ok: false, error: String(error?.message || error) });
        }
        // Page HTML is parsed by the packaged reader; rendered DOM needs no parse.
        const readHtml = () => {
            if (!html) return null;
            const page = root.GensparkArchiveHtml?.read(html, url);
            if (page?.markdown?.trim()) return page;
            attempts.push({ step: 'read', ok: false, error: 'noMarkdown' });
            return null;
        };
        if (html) {
            // Already rendered in a tab: hand back the DOM for the caller to read,
            // so a page that never parses still falls through to fetching below.
            if (renderPage) {
                result.ok = true;
                result.source = 'rendered';
                result.html = html;
            } else {
                const page = readHtml();
                if (page) Object.assign(result, { ok: true, source: 'page', markdown: page.markdown, imageUrls: page.imageUrls || [] });
            }
        }

        // 2. The raw document (share links and server-rendered pages need no login).
        if (!result.ok) {
            const fetched = await fetchText(fetchImpl, url, false);
            attempts.push({ step: 'fetchHtml', ok: Boolean(fetched.ok), status: fetched.status, error: fetched.error });
            if (fetched.ok) {
                html = fetched.body;
                const embedded = inlineState(html);
                const converted = embedded && fromJson(embedded, { title, url, extraUrls: filesInMarkup(html) });
                if (converted) {
                    Object.assign(result, { ok: true, source: 'inline-json', markdown: converted.messages.map(message => message.markdown).join('\n\n'),
                        imageUrls: converted.imageUrls, created: result.created || converted.created });
                } else if (looksLikeJson(html)) {
                    attempts.push({ step: 'read', ok: false, error: 'jsonDocument' });
                } else {
                    const page = readHtml();
                    if (page) Object.assign(result, { ok: true, source: 'html', markdown: page.markdown, imageUrls: page.imageUrls || [] });
                }
            }
        }

        // 3. Known conversation endpoints.
        if (!result.ok) {
            for (const endpoint of jsonEndpoints(url, id)) {
                const fetched = await fetchText(fetchImpl, endpoint, true);
                let payload;
                try { payload = fetched.ok ? JSON.parse(fetched.body) : null; } catch { payload = null; }
                const converted = payload && fromJson(payload, { title, url, extraUrls: filesInMarkup(html) });
                if (converted) {
                    Object.assign(result, { ok: true, source: 'api', markdown: converted.messages.map(message => message.markdown).join('\n\n'),
                        imageUrls: converted.imageUrls, created: result.created || converted.created, title: converted.title || result.title });
                    attempts.push({ step: 'json', url: endpoint, ok: true });
                    break;
                }
                attempts.push({ step: 'json', url: endpoint, ok: false, status: fetched.status, error: fetched.error || (payload ? 'noMessages' : 'notJson') });
            }
        }

        // Even without text, shareable image files are worth keeping.
        if (!result.ok && html) result.imageUrls = [...new Set([...result.imageUrls, ...filesInMarkup(html)])];
        return result;
    }

    root.GensparkArchive = { conversationId, jsonEndpoints, findMessages, normalizeMessages, fromJson, inlineState, archiveConversation, imageLinks, filesInMarkup };
})(globalThis);


/* HTML → Markdown reader used for fetched conversation pages.
 * A small tag-soup parser (service workers have no DOMParser) builds only the
 * block-level elements markdown.js understands and wraps them in the message
 * containers the content script looks for. Transcripts pass through an
 * allowlist; the page body falls back to text when no messages are found.
 * The first version is intentionally conservative about what it keeps. */
(function (root) {
    'use strict';
    const VOID = new Set(['area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'param', 'source', 'track', 'wbr']);
    const DROP = new Set(['script', 'style', 'noscript', 'template', 'svg', 'math', 'nav', 'aside', 'form']);
    const RAW_TEXT = new Set(['script', 'style', 'noscript', 'template', 'textarea', 'title']);
    const BLOCK = new Set(['p', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'ul', 'ol', 'li', 'pre', 'blockquote', 'table', 'thead', 'tbody', 'tr', 'td', 'th', 'figure', 'figcaption', 'details', 'summary', 'hr', 'div', 'section', 'article', 'main', 'header', 'footer', 'br']);
    const INLINE = new Set(['a', 'strong', 'b', 'em', 'i', 'del', 's', 'code', 'span', 'img', 'time', 'small', 'u', 'mark', 'sub', 'sup']);
    const TRANSCRIPT_SELECTOR = /(?:^|\s)(?:wb-msg-user-row|wb-asst-block|sas-asst-msg|conversation-statement|conversation-item-desc|user-message|assistant-message|markdown-viewer|markdown-body)(?:\s|$)/;
    const ENTITIES = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ', '#39': "'", copy: '(c)', mdash: '—', ndash: '–', hellip: '…' };

    const decode = value => String(value).replace(/&(#x?[0-9a-f]+|\w+);/gi, (whole, name) => {
        if (/^#x/i.test(name)) return String.fromCodePoint(parseInt(name.slice(2), 16) || 0x20);
        if (name[0] === '#') return String.fromCodePoint(Number(name.slice(1)) || 0x20);
        return ENTITIES[name.toLowerCase()] ?? whole;
    });

    function attrsOf(raw) {
        const attrs = {};
        for (const match of raw.matchAll(/([\w:-]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'>]+)))?/g)) {
            const name = match[1].toLowerCase();
            if (!(name in attrs)) attrs[name] = decode(match[2] ?? match[3] ?? match[4] ?? '');
        }
        return attrs;
    }

    /**
     * Parse markup into nodes { tag, attrs, children } / { text }.
     * @param {object} [rules]
     * @param {boolean} [rules.keepChrome] keep header/nav/form etc. (transcripts need them for detection)
     * @param {boolean} [rules.textMode] keep block and inline tags only, drop layout wrappers
     */
    function parse(html, rules = {}) {
        const source = String(html || '').replace(/<!--[\s\S]*?-->/g, '').replace(/<!\[CDATA\[[\s\S]*?\]\]>/g, '');
        const root_ = { tag: '#root', attrs: {}, children: [] };
        const stack = [root_];
        const top = () => stack[stack.length - 1];
        const kept = tag => rules.keepChrome ? true : !DROP.has(tag);
        const allowed = tag => !rules.textMode || BLOCK.has(tag) || INLINE.has(tag) || tag === 'title';
        const token = /<(\/?)([a-z][\w:-]*)((?:[^>"']|"[^"]*"|'[^']*')*?)(\/?)>|<(?:!|\?)[^>]*>/gi;
        let cursor = 0, match;
        const addText = value => {
            if (!value) return;
            const text_ = decode(value).replace(/[\t\f\r\n ]+/g, ' ');
            if (text_) top().children.push({ text: text_ });
        };
        while ((match = token.exec(source))) {
            addText(source.slice(cursor, match.index));
            cursor = token.lastIndex;
            if (!match[2]) continue;
            const tag = match[2].toLowerCase();
            if (match[1]) {
                for (let index = stack.length - 1; index > 0; index--) {
                    if (stack[index].tag === tag) { stack.length = index; break; }
                }
                continue;
            }
            // Script-like elements are skipped with their raw contents.
            if (RAW_TEXT.has(tag) && tag !== 'title') {
                const closer = new RegExp(`</${tag}\\s*>`, 'i');
                const found = closer.exec(source.slice(cursor));
                cursor += found ? found.index + found[0].length : source.length;
                token.lastIndex = cursor;
                continue;
            }
            if (!kept(tag) || !allowed(tag)) continue;
            const node = { tag, attrs: attrsOf(match[3] || ''), children: [] };
            top().children.push(node);
            if (VOID.has(tag) || match[4] === '/') continue;
            const parent = top();
            // Content-model repair for sanitized markup: a block inside <p> or a
            // nested <p>/<li>/table cell cannot nest, so the wrapper is closed.
            const closesParent = (parent.tag === 'p' && BLOCK.has(tag)) ||
                (tag === 'p' && parent.tag === 'p') ||
                (tag === 'li' && (parent.tag === 'li' || parent.tag === 'ul' || parent.tag === 'ol')) ||
                (['tr', 'td', 'th', 'thead', 'tbody'].includes(tag) && ['td', 'th', 'tr'].includes(parent.tag)) ||
                (tag === 'a' && parent.tag === 'a');
            if (closesParent) {
                stack.length = Math.max(1, stack.length - 1);
            }
            stack.push(node);
        }
        addText(source.slice(cursor));
        return root_;
    }

    const walk = (node, visit) => {
        if (node.text !== undefined) { visit(node); return; }
        for (const child of node.children) walk(child, visit);
    };
    const find = (node, predicate) => {
        if (node.text !== undefined) return null;
        if (predicate(node)) return node;
        for (const child of node.children) {
            const found = find(child, predicate);
            if (found) return found;
        }
        return null;
    };
    const findAll = (node, predicate, out = []) => {
        if (node.text !== undefined) return out;
        for (const child of node.children) {
            if (predicate(child)) out.push(child);
            findAll(child, predicate, out);
        }
        return out;
    };
    const textOf = node => {
        if (node.text !== undefined) return node.text;
        if (node.tag === 'br') return '\n';
        return (node.children || []).map(textOf).join(node.tag === 'pre' ? '' : '');
    };
    const classes = node => (node.attrs?.class || '').split(/\s+/).filter(Boolean);
    const hasClass = (node, pattern) => classes(node).some(name => pattern.test(name));

    /** Serialize an allowed node subtree into HTML for markdown.js. */
    function serialize(node, base) {
        if (node.text !== undefined) return node.text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
        const tag = node.tag;
        const inner = () => (node.children || []).map(child => serialize(child, base)).join('');
        if (tag === 'img') {
            // A lazy-loaded thumbnail has an empty src and the full image in data-src.
            const src = node.attrs.src || node.attrs['data-src'] || node.attrs['data-original'] || '';
            if (!src) return '';
            return `<img src="${src.replace(/&/g, '&amp;').replace(/"/g, '&quot;')}" alt="${(node.attrs.alt || '').replace(/&/g, '&amp;').replace(/"/g, '&quot;')}">`;
        }
        if (tag === 'br') return '<br>';
        if (tag === 'hr') return '<hr>';
        if (tag === 'a') {
            let href = node.attrs.href || '';
            try { href = href ? new URL(href, base).href : ''; } catch { href = ''; }
            return /^https?:/i.test(href) || !href ? `<a href="${href.replace(/"/g, '&quot;')}">${inner()}</a>` : inner();
        }
        if (/^h[1-6]$/.test(tag)) return `<h${tag[1]}>${inner()}</h${tag[1]}>`;
        if (tag === 'li') return `<li>${inner()}</li>`;
        if (tag === 'ul' || tag === 'ol') {
            const start = tag === 'ol' && /^\d+$/.test(node.attrs.start || '') ? ` start="${node.attrs.start}"` : '';
            return `<${tag}${start}>${inner()}</${tag}>`;
        }
        if (tag === 'strong' || tag === 'b') return `<strong>${inner()}</strong>`;
        if (tag === 'em' || tag === 'i') return `<em>${inner()}</em>`;
        if (tag === 'del' || tag === 's') return `<del>${inner()}</del>`;
        if (tag === 'code') return `<code>${textOf(node).replace(/&/g, '&amp;').replace(/</g, '&lt;')}</code>`;
        if (tag === 'pre') return `<pre><code>${textOf(node).replace(/&/g, '&amp;').replace(/</g, '&lt;')}</code></pre>`;
        if (tag === 'blockquote') return `<blockquote>${inner()}</blockquote>`;
        if (tag === 'table' || tag === 'thead' || tag === 'tbody') return `<table>${inner()}</table>`;
        if (tag === 'tr') return `<tr>${inner()}</tr>`;
        if (tag === 'td' || tag === 'th') return `<${tag}>${inner()}</${tag}>`;
        if (BLOCK.has(tag)) return `<p>${inner()}</p>`;
        return inner();
    }

    /** Find the message containers, falling back to the largest text block. */
    function transcriptNodes(tree) {
        return findAll(tree, node => {
            if (node.tag === '#root') return false;
            const haystack = `${node.attrs?.class || ''} ${node.attrs?.['data-testid'] || ''} ${node.attrs?.role || ''}`;
            return TRANSCRIPT_SELECTOR.test(haystack) && (node.attrs?.class || '').length && !hasClass(node, /^(?:wb-msg-user-text)$/);
        });
    }

    /** contains guard used to keep only the outermost message containers. */

    const MAKER = () => root.GensparkMarkdown && typeof root.GensparkMarkdown.htmlToMarkdown === 'function' ? root.GensparkMarkdown : null;

    function toContainer(messages, title, url) {
        const escapedTitle = String(title || '').replace(/&/g, '&amp;').replace(/</g, '&lt;');
        return `<html><head><title>${escapedTitle}</title></head><body><main><div class="conversation-wrapper">${messages.map((message, index) =>
            `<div class="${message.type === 'user' ? 'wb-msg-user-row' : 'sas-asst-msg'}" data-index="${index}">${message.outer}</div>`).join('')}</div></main></body></html>`;
    }

    /**
     * Read a fetched conversation page.
     * @returns {{ markdown: string, title: string, imageUrls: string[], messages: number } | null}
     */
    function read(html, url = 'https://www.genspark.ai/') {
        const markdown = MAKER();
        if (!markdown) return null;
        // Pass 1 finds transcripts (chrome kept); pass 2 reads the conversation
        // body with layout wrappers dropped and only the title kept from <head>.
        const tree = parse(html, { keepChrome: true });
        const titleNode = find(tree, node => node.tag === 'title');
        const title = decode(String(titleNode ? textOf(titleNode) : '').trim()).replace(/\s*[-|–—]\s*Genspark(?:\.ai)?\s*$/i, '').trim();
        const body = find(tree, node => node.tag === 'body') || tree;
        const nodes = transcriptNodes(body);
        const messages = [];
        for (const node of nodes) {
            if (nodes.some(other => other !== node && contains(other, node))) continue;
            const user = hasClass(node, /user|human/) || node.attrs?.['data-testid'] === 'user-message'
                ? 'user' : hasClass(node, /assistant|ai\b|asst/) ? 'assistant' : '';
            if (!user) continue;
            const outer = serialize(node, url);
            messages.push({ type: user, outer });
        }
        let markdownText = '';
        if (messages.length) {
            const wrapper = parse(toContainer(messages, title, url));
            const converted = markdown.htmlToMarkdown(serialize(wrapper, url), url);
            if (converted) markdownText = converted;
        }
        const imageUrls = messages.flatMap(message => Array.from(message.outer.matchAll(/<img[^>]*\bsrc="([^"]+)"/g), match =>
            decode(match[1]))).map(src => { try { return new URL(src, url).href; } catch { return ''; } }).filter(Boolean);
        if (!markdownText) {
            // No recognizable transcript: keep the readable body text so nothing is lost.
            const readable = parse(html, { textMode: true });
            const main = find(readable, node => node.tag === 'main') || find(readable, node => node.tag === 'body') || readable;
            const { text } = blockText(main, url, { skipChrome: true });
            if (!text) return null;
            // A sign-in screen is not a conversation: report it instead of
            // exporting the login page's own wording as the answer.
            const hasForm = /<(form|input)\b/i.test(html);
            if (hasForm && text.replace(/\s+/g, ' ').length < 200 && !/!\[/.test(text)) return null;
            return { markdown: text, title, imageUrls: Array.from(text.matchAll(/<([^>]+)>/g)).map(match => match[1]).concat(imageUrls), messages: 0, plain: true };
        }
        // Markdown image links the component cards do not expose as <img>.
        // (This IIFE is separate from GensparkArchive; its regexes live here.)
        const linked = Array.from(markdownText.matchAll(/!\[[^\]]*\]\((?:<([^>]+)>|([^)\s]+))\)/g), match => (match[1] || match[2] || '').trim())
            .map(source => { try { return new URL(source, url).href; } catch { return ''; } }).filter(Boolean);
        return { markdown: markdownText, title, imageUrls: [...new Set([...linked, ...imageUrls])], messages: messages.length };
    }

    const contains = (parent, node) => {
        if (parent === node) return true;
        if (parent.text !== undefined) return false;
        return parent.children.some(child => contains(child, node));
    };

    /**
     * Readable text of a subtree.
     * @param {object} [options]
     * @param {boolean} [options.skipChrome] drop forms/buttons and report whether any were seen
     * @returns {{ text: string, chrome: boolean }}  `chrome` is true for a plain string input.
     */
    function blockText(node, base = 'https://www.genspark.ai/', options = {}) {
        const walk = current => {
            if (current.text !== undefined) return current.text;
            if (options.skipChrome && (current.tag === 'form' || current.tag === 'button' || current.tag === 'input')) {
                state.chrome = true;
                return '';
            }
            if (current.tag === 'img') {
                const src = current.attrs?.['data-src'] || current.attrs?.src;
                if (!src) return '';
                try { return `\n\n![${current.attrs.alt || ''}](<${new URL(src, base).href}>)\n\n`; } catch { return ''; }
            }
            if (current.tag === 'br') return '\n';
            const inner = current.children.map(walk).join('');
            if (/^h[1-6]$/.test(current.tag)) return `\n\n${'#'.repeat(Number(current.tag[1]))} ${inner.replace(/\s+/g, ' ').trim()}\n\n`;
            if (current.tag === 'li') return `\n- ${inner.replace(/\s+/g, ' ').trim()}`;
            return BLOCK.has(current.tag) ? `\n\n${inner.trim()}\n\n` : inner;
        };
        const state = { chrome: false, form: false };
        const text = walk(node);
        return { text, chrome: state.form };
    }

    root.GensparkArchiveHtml = { read, parse, serialize };
})(globalThis);
