/**
 * Genspark Conversation Manager v2.6 - Background Service Worker
 * שירות רקע לניהול התוסף
 */

/**
 * Open a conversation in a hidden tab, let its content script describe itself,
 * and return the page HTML plus the detected title. An already open tab is
 * reused (never closed); a tab created here is closed again afterwards. The
 * document is read only once the page has been complete for a settle period,
 * so the app has rendered the transcript. Resolves to null on timeout, and the
 * caller falls back to fetching the URL directly.
 */
async function renderPageInTab(sendMessage, excludeTabId, url, { timeout = 35000, poll = 1500, settle = 3000, browser = typeof chrome !== 'undefined' ? chrome : null } = {}) {
    if (!browser?.tabs?.create || !url) return null;
    const matching = await browser.tabs.query({ url: ['*://*.genspark.ai/*', '*://genspark.ai/*'] }).catch(() => []);
    const target = (matching || []).find(tab => tab.url === url);
    const tab = target || await browser.tabs.create({ url, active: false });
    const started = Date.now();
    let completeAt = 0;
    try {
        while (Date.now() - started < timeout) {
            await new Promise(resolve => setTimeout(resolve, target ? 50 : poll));
            const state = await browser.tabs.get(tab.id).catch(() => null);
            if (!state) return null;
            if (state.status !== 'complete') { completeAt = 0; continue; }
            completeAt ||= Date.now();
            if (Date.now() - completeAt < settle && !target) continue;
            let response;
            try {
                response = await sendMessage({ action: 'describeForArchive', tabId: tab.id }, tab.id);
            } catch {
                response = null;
            }
            if (response?.success && response.html) {
                return { html: response.html, title: response.title || '', created: response.created || '' };
            }
        }
        return null;
    } finally {
        if (!target && tab?.id) await browser.tabs.remove(tab.id).catch(() => {});
    }
}

/**
 * Fetch through a hidden extension page when the plain fetch did not get the
 * page. Requests from an extension page are same-origin with genspark.ai, so
 * login cookies are sent (SameSite would hide them from a service-worker
 * request); the page has the same host permissions. Returns the plain result
 * unless the in-page fetch succeeds.
 */
async function fetchInPage(fetchImpl, url, { timeout = 20000, browser = typeof chrome !== 'undefined' ? chrome : null, method = 'get' } = {}) {
    if (method === 'get') {
        const direct = await fetchImpl(url, { credentials: 'include', redirect: 'follow', headers: { Accept: 'text/html,application/xhtml+xml' } })
            .then(async response => ({ ok: response.ok, status: response.status, body: await response.text(), contentType: response.headers.get('content-type') || '' }))
            .catch(error => ({ ok: false, status: 0, error: String(error?.message || error) }));
        if (direct.ok && direct.body) return direct;
    }
    const readerUrl = browser?.runtime?.getURL?.('archive.html');
    if (!readerUrl) return { ok: false, status: 0, error: 'noReaderPage' };
    let tab;
    try {
        tab = await browser.tabs.create({ url: readerUrl, active: false });
        const deadline = Date.now() + timeout;
        while (Date.now() < deadline) {
            await new Promise(resolve => setTimeout(resolve, 500));
            const frame = await browser.scripting.executeScript({
                target: { tabId: tab.id },
                args: [url],
                func: async target => {
                    const response = await fetch(target, { credentials: 'include', headers: { Accept: 'text/html,application/xhtml+xml' } });
                    return { ok: response.ok, status: response.status, contentType: response.headers.get('content-type') || '', body: await response.text() };
                }
            }).catch(() => null);
            const result = frame?.[0]?.result;
            // A 404 JSON body is a definite answer; keep looking only while the
            // reader page itself is still starting up.
            if (result?.status) return result;
            const state = await browser.tabs.get(tab.id).catch(() => null);
            if (!state) break;
        }
        return { ok: false, status: 0, error: 'timeout' };
    } catch (error) {
        return { ok: false, status: 0, error: String(error?.message || error) };
    } finally {
        if (tab?.id) await browser.tabs.remove(tab.id).catch(() => {});
    }
}

/**
 * Bounded-concurrency map. Kept module-level so it can be tested in Node.
 */
async function runLimited(items, limit, worker) {
    const results = new Array(items.length);
    let next = 0;
    const lanes = Array.from({ length: Math.max(1, Math.min(limit, items.length)) }, async () => {
        while (next < items.length) {
            const index = next++;
            results[index] = await worker(items[index], index);
        }
    });
    await Promise.all(lanes);
    return results;
}

/**
 * Download a set of files into one folder using chrome.downloads. Files are
 * queued in plan order; concurrency only limits how many are in flight, so
 * generated images keep their conversation order in the download list.
 */
async function downloadFiles(files, { folder = '', concurrency = 3, createDownloads = options => chrome.downloads.download(options) } = {}) {
    const cleanFolder = String(folder || '').replace(/^[\\/]+|[\\/]+$/g, '');
    const results = await runLimited(files, concurrency, async file => {
        const saveAs = Boolean(file.saveAs);
        const target = `${cleanFolder ? `${cleanFolder}/` : ''}${file.path}`;
        try {
            const id = await createDownloads({ url: file.url, filename: target, saveAs, conflictAction: 'uniquify' });
            return { path: file.path, id, success: true };
        } catch (error) {
            return { path: file.path, success: false, error: error?.message || String(error) };
        }
    });
    const failed = results.filter(result => !result.success);
    return { success: failed.length === 0, downloaded: results.length - failed.length, total: results.length, failed, files: results };
}

/** Fetch bytes with bounded size and a timeout; never throws. */
async function fetchBytes(url, { maxBytes = 40 * 1024 * 1024, timeout = 45000 } = {}) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeout);
    // Login cookies only matter for Genspark's own hosts; third-party images
    // are more likely to answer a plain request.
    let host = '';
    try { host = new URL(url).hostname; } catch { /* fetch will report it */ }
    const credentials = /(?:^|\.)genspark\.ai$/.test(host) ? 'include' : 'omit';
    try {
        const response = await fetch(url, { credentials, signal: controller.signal });
        if (!response.ok) return { ok: false, status: response.status, error: `HTTP ${response.status}` };
        const type = (response.headers.get('content-type') || '').split(';')[0].trim();
        const buffer = new Uint8Array(await response.arrayBuffer());
        if (buffer.byteLength > maxBytes) return { ok: false, status: response.status, error: 'tooLarge' };
        if (!/^image\//.test(type) && !/octet-stream/.test(type)) return { ok: false, status: response.status, error: `notAnImage:${type || 'unknown'}` };
        return { ok: true, status: response.status, type, bytes: buffer };
    } catch (error) {
        return { ok: false, status: 0, error: error?.name === 'AbortError' ? 'timeout' : error?.message || String(error) };
    } finally {
        clearTimeout(timer);
    }
}

const base64ToBytes = value => Uint8Array.from(atob(String(value).replace(/^data:[^,]*,/, '')), character => character.charCodeAt(0));

function toBase64(value) {
    const bytes = value instanceof Uint8Array ? value : new TextEncoder().encode(String(value));
    let binary = '';
    for (let offset = 0; offset < bytes.length; offset += 0x8000) {
        binary += String.fromCharCode(...bytes.subarray(offset, offset + 0x8000));
    }
    return btoa(binary);
}

const CRC_TABLE = Array.from({ length: 256 }, (_, index) => {
    let value = index;
    for (let bit = 0; bit < 8; bit++) value = value & 1 ? 0xEDB88320 ^ (value >>> 1) : value >>> 1;
    return value >>> 0;
});
function crc32(bytes) {
    let crc = 0xFFFFFFFF;
    for (const byte of bytes) crc = CRC_TABLE[(crc ^ byte) & 0xFF] ^ (crc >>> 8);
    return (crc ^ 0xFFFFFFFF) >>> 0;
}

/**
 * Minimal store-only (method 0) ZIP writer. UTF-8 file names are flagged,
 * so Japanese folder and file names survive extraction on Windows.
 */
function buildZipArchive(files, date = new Date()) {
    const dosTime = (date.getHours() << 11) | (date.getMinutes() << 5) | Math.floor(date.getSeconds() / 2);
    const dosDate = ((date.getFullYear() - 1980) << 9) | ((date.getMonth() + 1) << 5) | date.getDate();
    const encoder = new TextEncoder();
    const chunks = [], central = [];
    let offset = 0;
    for (const file of files) {
        const name = encoder.encode(file.name.replace(/\\/g, '/').replace(/^\/+/, ''));
        const data = file.bytes instanceof Uint8Array ? file.bytes : encoder.encode(String(file.bytes ?? ''));
        // Lengths are recorded from the encoded bytes, so multi-byte names are fine.
        if (!name.length) continue;
        const crc = crc32(data);
        const local = new Uint8Array(30 + name.length);
        const localView = new DataView(local.buffer);
        localView.setUint32(0, 0x04034B50, true);
        localView.setUint16(4, 20, true);
        localView.setUint16(6, 0x0800, true);
        localView.setUint16(8, 0, true);
        localView.setUint16(10, dosTime, true);
        localView.setUint16(12, dosDate, true);
        localView.setUint32(14, crc, true);
        localView.setUint32(18, data.length, true);
        localView.setUint32(22, data.length, true);
        localView.setUint16(26, name.length, true);
        local.set(name, 30);
        const record = new Uint8Array(46 + name.length);
        const recordView = new DataView(record.buffer);
        recordView.setUint32(0, 0x02014B50, true);
        recordView.setUint16(4, 20, true);
        recordView.setUint16(6, 20, true);
        recordView.setUint16(8, 0x0800, true);
        recordView.setUint16(10, 0, true);
        recordView.setUint16(12, dosTime, true);
        recordView.setUint16(14, dosDate, true);
        recordView.setUint32(16, crc, true);
        recordView.setUint32(20, data.length, true);
        recordView.setUint32(24, data.length, true);
        recordView.setUint16(28, name.length, true);
        recordView.setUint32(42, offset, true);
        record.set(name, 46);
        chunks.push(local, data);
        central.push(record);
        offset += local.length + data.length;
    }
    const directorySize = central.reduce((total, record) => total + record.length, 0);
    const end = new Uint8Array(22);
    const endView = new DataView(end.buffer);
    endView.setUint32(0, 0x06054B50, true);
    endView.setUint16(8, central.length, true);
    endView.setUint16(10, central.length, true);
    endView.setUint32(12, directorySize, true);
    endView.setUint32(16, offset, true);
    const all = [...chunks, ...central, end];
    const output = new Uint8Array(all.reduce((total, part) => total + part.length, 0));
    let cursor = 0;
    for (const part of all) { output.set(part, cursor); cursor += part.length; }
    return { base64: toBase64(output), entries: files.length, bytes: output.length };
}

class BackgroundService {
    constructor() {
        this.version = '2.6';
        this.isActive = true;
        this.tabStates = new Map();

        this.init();
    }

    init() {
        this.setupEventListeners();
        this.loadSettings();

        console.log(`🔧 Background Service v${this.version} אותחל`);
    }

    setupEventListeners() {
        // התקנת התוסף
        chrome.runtime.onInstalled.addListener((details) => {
            this.handleInstallation(details);
        });

        // הודעות בין רכיבים
        chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
            this.handleMessage(request, sender, sendResponse);
            return true; // שמור חיבור אסינכרוני
        });

        // עדכוני טאבים
        chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
            this.handleTabUpdate(tabId, changeInfo, tab);
        });

        // סגירת טאבים
        chrome.tabs.onRemoved.addListener((tabId, removeInfo) => {
            this.handleTabRemoved(tabId);
        });

        // אירועי חלונות
        chrome.windows.onRemoved.addListener((windowId) => {
            this.handleWindowClosed(windowId);
        });
    }

    async handleInstallation(details) {
        console.log('התקנת תוסף:', details);

        if (details.reason === 'install') {
            // התקנה ראשונה
            await this.setDefaultSettings();
            this.showWelcomeNotification();

        } else if (details.reason === 'update') {
            // עדכון גרסה
            const previousVersion = details.previousVersion;
            console.log(`עדכון מגרסה ${previousVersion} לגרסה ${this.version}`);

            await this.migrateSettings(previousVersion);
            this.showUpdateNotification(previousVersion);
        }
    }

    async setDefaultSettings() {
        const defaultSettings = {
            autoDownload: false,
            downloadFormat: 'both',
            showNotifications: true,
            version: this.version,
            installDate: new Date().toISOString()
        };

        await chrome.storage.sync.set(defaultSettings);
        console.log('הגדרות ברירת מחדל נשמרו:', defaultSettings);
    }

    async migrateSettings(previousVersion) {
        try {
            const currentSettings = await chrome.storage.sync.get();

            // הוסף הגדרות חדשות שלא היו בגרסה הקודמת
            const updates = {
                version: this.version,
                lastUpdate: new Date().toISOString()
            };

            // Migration logic לגרסאות ספציפיות
            if (this.compareVersions(previousVersion, '2.0') < 0) {
                // שינויים מגרסה 2.0
                updates.showNotifications = currentSettings.showNotifications ?? true;
            }

            if (this.compareVersions(previousVersion, '2.3') < 0) {
                // שינויים מגרסה 2.3  
                updates.downloadFormat = currentSettings.downloadFormat || 'both';
            }

            await chrome.storage.sync.set(updates);
            console.log('הגדרות הועברו בהצלחה:', updates);

        } catch (error) {
            console.error('שגיאה במעבר הגדרות:', error);
        }
    }

    compareVersions(version1, version2) {
        const v1parts = version1.split('.').map(Number);
        const v2parts = version2.split('.').map(Number);

        for (let i = 0; i < Math.max(v1parts.length, v2parts.length); i++) {
            const v1part = v1parts[i] || 0;
            const v2part = v2parts[i] || 0;

            if (v1part < v2part) return -1;
            if (v1part > v2part) return 1;
        }

        return 0;
    }

    async loadSettings() {
        try {
            const settings = await chrome.storage.sync.get();
            console.log('הגדרות נטענו:', settings);
            return settings;
        } catch (error) {
            console.error('שגיאה בטעינת הגדרות:', error);
            return {};
        }
    }

    async handleMessage(request, sender, sendResponse) {
        console.log('הודעה התקבלה:', request, 'מאת:', sender);

        try {
            switch (request.action) {
                case 'getSettings':
                    const settings = await this.loadSettings();
                    sendResponse({ success: true, settings });
                    break;

                case 'saveSettings':
                    await chrome.storage.sync.set(request.settings);
                    sendResponse({ success: true });
                    break;

                case 'getVersion':
                    sendResponse({ version: this.version });
                    break;

                case 'getTabState':
                    const tabState = this.tabStates.get(sender.tab?.id);
                    sendResponse({ tabState: tabState || {} });
                    break;

                case 'setTabState':
                    if (sender.tab?.id) {
                        this.tabStates.set(sender.tab.id, request.state);
                        sendResponse({ success: true });
                    }
                    break;

                case 'trackUsage':
                    await this.trackUsage(request.event, request.data);
                    sendResponse({ success: true });
                    break;

                // conversation → Markdown + images folder (optionally zipped),
                // downloaded together so the Markdown's relative image links work.
                case 'downloadConversationBundle':
                    // The message port closes if this exceeds ~30 s; the download
                    // keeps running and is tracked by folder settings instead.
                    sendResponse({ success: true, queued: true, total: request.files?.length || 0, folder: request.folder || '' });
                    this.downloadBundle(request).catch(error => console.error('❌ שגיאה בהורדת החבילה:', error));
                    return false;

                case 'getSavedExportFolder':
                    sendResponse({ folder: await this.getSavedExportFolder() });
                    break;

                // Conversations that are not open in a tab (session archive).
                case 'archiveConversation':
                    if (request.format === 'json') {
                        this.downloadArchiveJson(request).catch(error => console.error('❌ ארכיון JSON:', error));
                    } else {
                        this.exportArchivedConversation(request).catch(error => console.error('❌ ארכיון Markdown:', error));
                    }
                    sendResponse({ success: true, queued: true });
                    return false;

                case 'renderForArchive':
                    renderPageInTab(msg => sendResponse(msg), sender.tab?.id, request.url)
                        .then(result => sendResponse({ success: true, ...result }))
                        .catch(error => sendResponse({ success: false, error: error?.message || 'renderFailed' }));
                    return true;

                case 'chooseExportFolder':
                    sendResponse({ success: false, errorCode: 'unsupported' });
                    break;

                default:
                    sendResponse({ error: 'פעולה לא מזוהה' });
            }
        } catch (error) {
            console.error('שגיאה בטיפול בהודעה:', error);
            sendResponse({ error: error.message });
        }
    }

    async getSavedExportFolder() {
        try {
            const { exportFolder } = await chrome.storage.local.get('exportFolder');
            return String(exportFolder || '').replace(/^[\\/]+|[\\/]+$/g, '');
        } catch {
            return '';
        }
    }

    async rememberExportFolder(path) {
        const segments = String(path || '').split(/[\\/]+/).filter(Boolean);
        // Drop the file name; keep at most Folder/Subfolder as the default target.
        const folder = segments.slice(0, -1).slice(-2).join('/');
        if (folder) {
            await chrome.storage.local.set({ exportFolder: folder });
            return folder;
        }
        return this.getSavedExportFolder();
    }

    async downloadBundle({ files = [], markdown = '', markdownName = 'conversation.md', folder = '', zip }) {
        const onChanged = details => {
            if (details.state === 'complete' && details.fileName) {
                this.rememberExportFolder(details.filename || details.fileName.replace(/[\\/][^\\/]*$/, ''))
                    .catch(error => console.warn('לא ניתן לזכור את תיקיית הייצוא:', error));
            }
        };
        const listening = typeof chrome.downloads.onChanged?.addListener === 'function';
        if (listening) chrome.downloads.onChanged.addListener(onChanged);
        try {
            // A plan without images (or a legacy "single .md" export) asks for one save dialog.
            const entries = Array.isArray(files) ? files.filter(file => file && file.url && file.path) : [];
            if (zip?.include) {
                const archive = await this.buildZip(entries, markdown, markdownName);
                const zipPath = zip.path || 'conversation.zip';
                if (!archive?.base64) return { success: false, downloaded: 0, total: entries.length + 1, error: 'zipFailed', failed: [{ path: zipPath, error: 'zipFailed' }] };
                const saved = await downloadFiles([{ url: `data:application/zip;base64,${archive.base64}`, path: zipPath }], { folder, concurrency: 1 });
                return { ...saved, method: 'zip', zipEntries: archive.entries, bytes: archive.bytes };
            }
            const batch = entries.map(file => ({ url: file.url, path: file.path }));
            // The Markdown file is queued last so the images already exist when it lands.
            if (markdown) batch.push({ url: `data:text/markdown;charset=utf-8;base64,${toBase64(markdown)}`, path: markdownName || 'conversation.md' });
            const result = await downloadFiles(batch, { folder });
            if (entries.length && !result.downloaded) {
                // Direct downloads were refused (e.g. URL not host-accessible):
                // fall back to fetching in the service worker (cookies are still
                // sent) and downloading the bytes as data URLs.
                const fallback = await this.fetchAndDownload(entries, markdown, markdownName, folder);
                if (fallback.downloaded) return fallback;
            }
            return result;
        } finally {
            if (listening) chrome.downloads.onChanged.removeListener(onChanged);
        }
    }

    async fetchAndDownload(entries, markdown, markdownName, folder) {
        const fetched = await runLimited(entries, 3, async entry => {
            const result = await fetchBytes(entry.url);
            return result.ok ? { url: `data:${result.type || 'image/png'};base64,${toBase64(result.bytes)}`, path: entry.path } : { path: entry.path, failed: result.error };
        });
        const batch = fetched.filter(item => item.url).map(item => ({ url: item.url, path: item.path }));
        if (markdown) batch.push({ url: `data:text/markdown;charset=utf-8;base64,${toBase64(markdown)}`, path: markdownName });
        const result = await downloadFiles(batch, { folder, concurrency: 1 });
        result.failed.push(...fetched.filter(item => item.failed).map(item => ({ path: item.path, error: item.failed })));
        result.success = result.failed.length === 0;
        result.method = 'data';
        return result;
    }

    /** `sendMessage` for renderPageInTab: asks a specific tab for its document. */
    tabBus() {
        return (request, tabId) => new Promise((resolve, reject) => {
            chrome.tabs.sendMessage(tabId, request, response => {
                const error = chrome.runtime.lastError;
                if (error) reject(new Error(error.message));
                else resolve(response);
            });
        });
    }

    async archiveFull(url, title) {
        const archived = await GensparkArchive.archiveConversation({
            url, title,
            // Hidden tab first (the app's own renderer), then the raw document,
            // then endpoints. Fetches go through the reader page so login
            // cookies are sent.
            renderPage: target => renderPageInTab(this.tabBus(), null, target),
            fetch: (target, options = {}) => fetchInPage((input, init) => fetch(input, init), target, options)
        });
        if (archived.source === 'rendered' && archived.html) {
            // The tab is closed by now; read the DOM the content script handed over.
            const page = GensparkArchiveHtml.read(archived.html, url);
            if (page?.markdown?.trim()) {
                Object.assign(archived, { ok: true, source: 'tab', markdown: page.markdown, imageUrls: page.imageUrls || [], messages: [] });
            } else {
                archived.ok = false;
                archived.attempts.push({ step: 'read', ok: false, error: 'noMarkdown' });
            }
            delete archived.html;
        }
        return archived;
    }

    /** Session archive → "<date>-<title>.md" + "<date>-<title>_assets/images/*". */
    async exportArchivedConversation({ url, title = '', folder = '', zip = false }) {
        const archived = await this.archiveFull(url, title);
        const names = GensparkMarkdown.exportNames(archived.title || title || 'Genspark conversation');
        const assetFolder = names.markdown.replace(/\.md$/, '_assets');
        const plan = GensparkMarkdown.planImages({ urls: archived.imageUrls, base: url });
        const linkOk = plan.entries.length > 0 && !zip;
        let markdown = GensparkMarkdown.renderConversation({
            title: archived.title || title || 'Genspark conversation', url,
            messages: archived.messages || [{ type: 'assistant', markdown: archived.markdown }],
            created: archived.created || ''
        });
        markdown = GensparkMarkdown.rewriteImageLinks(markdown, plan);
        if (!archived.ok) {
            markdown = `> [!warning] ${GensparkArchiveStatus.unreadable}\n\n${markdown}`;
        }
        await this.downloadBundle({
            folder: linkOk ? assetFolder : folder,
            files: linkOk ? plan.entries.map(entry => ({ url: entry.url, path: `${assetFolder}/${entry.path}` })) : [],
            markdown,
            markdownName: linkOk ? `${assetFolder}/${names.markdown}` : names.markdown,
            zip: zip ? { include: true, path: names.zip } : undefined
        });
        await this.trackUsage('archiveExport', { source: archived.source, ok: archived.ok, images: plan.entries.length }).catch(() => {});
        return archived;
    }

    async downloadArchiveJson({ urls = [], folder = '' }) {
        const results = await runLimited(urls, 2, async url => {
            const archived = await this.archiveFull(url, '');
            return { url, ...archived };
        });
        const json = JSON.stringify({ exported_at: new Date().toISOString(), count: results.length, conversations: results }, null, 2);
        const stamp = new Date().toISOString().replace(/[:.]/g, '-');
        return downloadFiles([{ url: `data:application/json;charset=utf-8;base64,${toBase64(json)}`, path: `genspark-archive-${stamp}.json` }], { folder });
    }

    // Store-only ZIP (no compression): Deflate is not available in a service
    // worker, and images are already compressed. Built in chunks so large
    // conversations do not hit string-size limits.
    async buildZip(entries, markdown, markdownName) {
        const files = [];
        const skipped = [];
        for (const entry of entries) {
            try {
                const source = /^data:/i.test(entry.url) ? { ok: true, bytes: base64ToBytes(entry.url) }
                    : await fetchBytes(entry.url);
                if (source.ok && source.bytes?.byteLength) files.push({ name: entry.path, bytes: source.bytes });
                else skipped.push({ path: entry.path, error: source.error || 'empty' });
            } catch (error) {
                skipped.push({ path: entry.path, error: error?.message || String(error) });
            }
        }
        if (markdown) files.push({ name: markdownName, bytes: new TextEncoder().encode(markdown) });
        return buildZipArchive(files);
    }

    handleTabUpdate(tabId, changeInfo, tab) {
        // עדכון כאשר טאב נטען
        if (changeInfo.status === 'complete' && tab.url?.includes('genspark.ai')) {
            console.log(`טאב Genspark נטען: ${tabId}`);

            // אתחל מצב טאב
            this.tabStates.set(tabId, {
                url: tab.url,
                title: tab.title,
                loadTime: new Date().toISOString()
            });
        }
    }

    handleTabRemoved(tabId) {
        // נקה מצב טאב שנסגר
        if (this.tabStates.has(tabId)) {
            console.log(`מנקה מצב עבור טאב: ${tabId}`);
            this.tabStates.delete(tabId);
        }
    }

    handleWindowClosed(windowId) {
        // נקה טאבים של חלון שנסגר
        const tabsToRemove = [];

        this.tabStates.forEach((state, tabId) => {
            // בדוק אם הטאב שייך לחלון שנסגר
            chrome.tabs.get(tabId).catch(() => {
                tabsToRemove.push(tabId);
            });
        });

        tabsToRemove.forEach(tabId => {
            this.tabStates.delete(tabId);
        });
    }

    async trackUsage(eventType, data = {}) {
        try {
            const usageData = {
                event: eventType,
                timestamp: new Date().toISOString(),
                version: this.version,
                ...data
            };

            // שמור נתוני שימוש (מקומי בלבד)
            const usage = await chrome.storage.local.get('usage') || { usage: [] };
            usage.usage = usage.usage || [];
            usage.usage.push(usageData);

            // שמור רק 1000 אירועים אחרונים
            if (usage.usage.length > 1000) {
                usage.usage = usage.usage.slice(-1000);
            }

            await chrome.storage.local.set({ usage: usage.usage });

            console.log('נתוני שימוש נשמרו:', usageData);

        } catch (error) {
            console.error('שגיאה במעקב שימוש:', error);
        }
    }

    showWelcomeNotification() {
        if (chrome.notifications) {
            chrome.notifications.create({
                type: 'basic',
                iconUrl: 'icon48.png',
                title: 'ברוכים הבאים ל-Genspark Conversation Manager!',
                message: 'התוסף הותקן בהצלחה. כעת תוכלו לחפש, להוריד ולנהל את השיחות שלכם מ-Genspark.ai'
            });
        }
    }

    showUpdateNotification(previousVersion) {
        if (chrome.notifications) {
            chrome.notifications.create({
                type: 'basic',
                iconUrl: 'icon48.png',
                title: 'Genspark Conversation Manager עודכן!',
                message: `התוסף עודכן מגרסה ${previousVersion} לגרסה ${this.version} עם פיצ'רים חדשים`
            });
        }
    }

    // פונקציות עזר
    async isGensparkTab(tabId) {
        try {
            const tab = await chrome.tabs.get(tabId);
            return tab.url?.includes('genspark.ai');
        } catch {
            return false;
        }
    }

    async getActiveGensparkTabs() {
        const tabs = await chrome.tabs.query({ 
            url: ['*://genspark.ai/*', '*://*.genspark.ai/*'] 
        });

        return tabs;
    }

    async injectContentScript(tabId) {
        try {
            await chrome.scripting.executeScript({
                target: { tabId },
                files: ['content.js']
            });

            console.log(`Content script הוזרק לטאב: ${tabId}`);
            return true;

        } catch (error) {
            console.error('שגיאה בהזרקת סקריפט:', error);
            return false;
        }
    }
}

// Node tests import the pure helpers; in the service worker class construction
// registers the listeners (hence only when extension APIs exist).
if (typeof chrome !== 'undefined' && chrome.runtime?.onMessage) {
    // אתחול שירות הרקע
    globalThis.backgroundService = new BackgroundService();
}
globalThis.GensparkBackgroundHelpers = { runLimited, downloadFiles, fetchBytes, buildZipArchive, crc32, toBase64, renderPageInTab };

/** Warning text embedded in archived Markdown that could not be read. */
globalThis.GensparkArchiveStatus = {
    unreadable: 'The conversation could not be exported (login required, or the page never rendered). Open the conversation in a tab and use the extension popup instead.'
};

// טיפול בשגיאות גלובליות
self.addEventListener('error', (event) => {
    console.error('Background service error:', event.error);
});

// התכוננות להשעיה (Service Worker lifecycle)
self.addEventListener('beforeunload', () => {
    console.log('Background service נכנס להשעיה');
});

console.log('🚀 Genspark Conversation Manager Background Service v2.6 פעיל');
